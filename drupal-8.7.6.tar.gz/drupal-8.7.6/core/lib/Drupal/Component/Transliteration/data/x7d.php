<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ji', 'cha', 'zhou', 'xun', 'yue', 'hong', 'yu', 'he', 'wan', 'ren', 'wen', 'wen', 'qiu', 'na', 'zi', 'tou',
  0x10 => 'niu', 'fou', 'ji', 'shu', 'chun', 'pi', 'zhen', 'sha', 'hong', 'zhi', 'ji', 'fen', 'yun', 'ren', 'dan', 'jin',
  0x20 => 'su', 'fang', 'suo', 'cui', 'jiu', 'za', 'ba', 'jin', 'fu', 'zhi', 'ci', 'zi', 'chou', 'hong', 'za', 'lei',
  0x30 => 'xi', 'fu', 'xie', 'shen', 'bo', 'zhu', 'qu', 'ling', 'zhu', 'shao', 'gan', 'yang', 'fu', 'tuo', 'zhen', 'dai',
  0x40 => 'chu', 'shi', 'zhong', 'xian', 'zu', 'jiong', 'ban', 'qu', 'mo', 'shu', 'zui', 'kuang', 'jing', 'ren', 'hang', 'xie',
  0x50 => 'jie', 'zhu', 'chou', 'gua', 'bai', 'jue', 'kuang', 'hu', 'ci', 'huan', 'geng', 'tao', 'jie', 'ku', 'jiao', 'quan',
  0x60 => 'gai', 'luo', 'xuan', 'beng', 'xian', 'fu', 'gei', 'dong', 'rong', 'tiao', 'yin', 'lei', 'xie', 'juan', 'xu', 'gai',
  0x70 => 'die', 'tong', 'si', 'jiang', 'xiang', 'hui', 'jue', 'zhi', 'jian', 'juan', 'chi', 'mian', 'zhen', 'lu', 'cheng', 'qiu',
  0x80 => 'shu', 'bang', 'tong', 'xiao', 'huan', 'qin', 'geng', 'xiu', 'ti', 'tou', 'xie', 'hong', 'xi', 'fu', 'ting', 'sui',
  0x90 => 'dui', 'kun', 'fu', 'jing', 'hu', 'zhi', 'yan', 'jiong', 'feng', 'ji', 'xu', 'ren', 'zong', 'chen', 'duo', 'li',
  0xA0 => 'lu', 'liang', 'chou', 'quan', 'shao', 'qi', 'qi', 'zhun', 'qi', 'wan', 'qian', 'xian', 'shou', 'wei', 'qi', 'tao',
  0xB0 => 'wan', 'gang', 'wang', 'beng', 'zhui', 'cai', 'guo', 'cui', 'lun', 'liu', 'qi', 'zhan', 'bi', 'chuo', 'ling', 'mian',
  0xC0 => 'qi', 'qie', 'tian', 'zong', 'gun', 'zou', 'xi', 'zi', 'xing', 'liang', 'jin', 'fei', 'rui', 'min', 'yu', 'zong',
  0xD0 => 'fan', 'lu', 'xu', 'ying', 'shang', 'qi', 'xu', 'xiang', 'jian', 'ke', 'xian', 'ruan', 'mian', 'ji', 'duan', 'chong',
  0xE0 => 'di', 'min', 'miao', 'yuan', 'xie', 'bao', 'si', 'qiu', 'bian', 'huan', 'geng', 'cong', 'mian', 'wei', 'fu', 'wei',
  0xF0 => 'tou', 'gou', 'miao', 'xie', 'lian', 'zong', 'bian', 'yun', 'yin', 'ti', 'gua', 'zhi', 'yun', 'cheng', 'chan', 'dai',
];
