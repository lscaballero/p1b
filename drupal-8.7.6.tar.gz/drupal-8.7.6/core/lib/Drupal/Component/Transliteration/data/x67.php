<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'zui', 'can', 'xu', 'hui', 'yin', 'qie', 'fen', 'pi', 'yue', 'you', 'ruan', 'peng', 'fen', 'fu', 'ling', 'fei',
  0x10 => 'qu', 'ti', 'nu', 'tiao', 'shuo', 'zhen', 'lang', 'lang', 'zui', 'ming', 'huang', 'wang', 'tun', 'chao', 'ji', 'qi',
  0x20 => 'ying', 'zong', 'wang', 'tong', 'lang', 'lao', 'meng', 'long', 'mu', 'deng', 'wei', 'mo', 'ben', 'zha', 'shu', 'shu',
  0x30 => 'mu', 'zhu', 'ren', 'ba', 'pu', 'duo', 'duo', 'dao', 'li', 'gui', 'ji', 'jiu', 'bi', 'xiu', 'cheng', 'ci',
  0x40 => 'sha', 'ru', 'za', 'quan', 'qian', 'yu', 'gan', 'wu', 'cha', 'shan', 'xun', 'fan', 'wu', 'zi', 'li', 'xing',
  0x50 => 'cai', 'cun', 'ren', 'biao', 'tuo', 'di', 'zhang', 'mang', 'chi', 'yi', 'gai', 'gong', 'du', 'li', 'qi', 'shu',
  0x60 => 'gang', 'tiao', 'jiang', 'shan', 'wan', 'lai', 'jiu', 'mang', 'yang', 'ma', 'miao', 'si', 'yuan', 'hang', 'fei', 'bei',
  0x70 => 'jie', 'dong', 'gao', 'yao', 'xian', 'chu', 'chun', 'pa', 'shu', 'hua', 'xin', 'chou', 'zhu', 'chou', 'song', 'ban',
  0x80 => 'song', 'ji', 'wo', 'jin', 'gou', 'ji', 'mao', 'pi', 'bi', 'wang', 'ang', 'fang', 'fen', 'yi', 'fu', 'nan',
  0x90 => 'xi', 'hu', 'ya', 'dou', 'xin', 'zhen', 'yao', 'lin', 'rui', 'e', 'mei', 'zhao', 'guo', 'zhi', 'cong', 'yun',
  0xA0 => 'zui', 'dou', 'shu', 'zao', 'duo', 'li', 'lu', 'jian', 'cheng', 'song', 'qiang', 'feng', 'nan', 'xiao', 'xian', 'ku',
  0xB0 => 'ping', 'tai', 'xi', 'zhi', 'guai', 'xiao', 'jia', 'jia', 'gou', 'bao', 'mo', 'yi', 'ye', 'ye', 'shi', 'nie',
  0xC0 => 'bi', 'duo', 'yi', 'ling', 'bing', 'ni', 'la', 'he', 'ban', 'fan', 'zhong', 'dai', 'ci', 'yang', 'fu', 'bai',
  0xD0 => 'mou', 'gan', 'qi', 'ran', 'rou', 'mao', 'shao', 'song', 'zhe', 'xia', 'you', 'shen', 'gui', 'tuo', 'zha', 'nan',
  0xE0 => 'ning', 'yong', 'di', 'zhi', 'zha', 'cha', 'dan', 'gu', 'bu', 'jiu', 'ao', 'fu', 'jian', 'ba', 'duo', 'ke',
  0xF0 => 'nai', 'zhu', 'bi', 'liu', 'chai', 'shan', 'si', 'chu', 'pei', 'shi', 'guai', 'zha', 'yao', 'cheng', 'jiu', 'shi',
];
